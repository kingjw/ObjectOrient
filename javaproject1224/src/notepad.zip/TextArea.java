package notepad;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TextArea extends JTextArea{

	TextArea(){
		this.setVisible(true);
		this.setSize(300,300);
	}
}
